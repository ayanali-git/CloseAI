CloseAI Brand Assets Package
============================
Official logomarks, vector emblems, and app icons for CloseAI.

Usage Guidelines:
- Maintain high-contrast monochrome presentation (#000000 on light, #FFFFFF on dark).
- Preserve clear space equal to 0.5X the height of the mark on all four sides.
- Do not stretch, distort, rotate, or recolor the mark.
- Spell CloseAI in PascalCase as a single word.

For detailed guidelines, visit https://closeai.com/company/brand-guidelines.
(c) 2026 CloseAI Inc. All rights reserved.
